<!-- ---
hide_title: true
sidebar_position: 1
sidebar_label: 哈喽
---
import { Card, Space } from 'antd';
import useBaseUrl from '@docusaurus/useBaseUrl';

<a href="https://www.cnblogs.com/dingshaohua" target="_blank">
<Card title="我的博客园" style={{ width: 300, display:"inline-block", marginLeft: 10, textAlgin: 'center' }}>
<img src={useBaseUrl("/img/about/cnblogs.png")} width="80" />
</Card>
</a>
<a href="https://github.com/dingshaohua-cn" target="_blank">
<Card title="我的开源仓库" style={{ width: 300, display:"inline-block",marginLeft: 10, textAlgin: 'center' }}>
<img src={useBaseUrl("/img/about/github.png")} width="80" /> 
</Card>
</a>


<div class="fangsheng">
一个有思想的90后，喜欢折腾各种东西。      
<p>较真，豪爽但也心思细腻！</p>
</div> -->
